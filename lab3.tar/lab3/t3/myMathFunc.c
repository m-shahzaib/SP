//#include<stdio.h>

int isEqual(int x,int y)
{
	if(x==y)
		return 1;
	else
		return -1;
}

void swap(int *x,int *y)
{
	int w=*x;
	*x=*y;
	*y=w;
	//printf ("after swapping x=%d and y=%d\n", x,y);
}
