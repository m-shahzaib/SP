#include <stdio.h>
#include "myMath.h"
#include "myStr.h"

int main()
{

	int x =23;
	int y =32;

	printf("Initially X is :");
	printf("%d",x);
	printf("\n");

	printf("Initially Y is :");
	printf("%d",y);
	printf("\n");
	

	if (isEqual(x,y) == 1 )
		printf("Equal \n" );
	else
		printf(" Not Equal \n");
	swap(&x,&y);
	
	printf("Now X is :");
	printf("%d",x);
	printf("\n");

	printf("Now Y is :");
	printf("%d",y);
	printf("\n");


	char *c = "abba";
	if(isPalindrome(c,4)==1)
		printf("It is palindrome \n");
	else
		printf("It is not Palindrome \n");
	return 0;
}
