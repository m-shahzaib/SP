int isPalindrome(char *arr,int size)
{
	for(int i=0;i<size;i++)
	{
		if(arr[i]==arr[size-1])
		{
			continue;
		}
		else
			return -1;
	}
	return 1;
}