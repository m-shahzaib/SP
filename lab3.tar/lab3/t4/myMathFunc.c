#include<stdio.h>
int isEqual(int x,int y)
{
	printf ("hay this is isEqual function\n");
	if(x==y)
		return 1;
	else
		return -1;
	printf ("hay this is isEqual function\n");
}

void swap(int *x,int *y)
{
	int w=*x;
	*x=*y;
	*y=w;
	printf ("hay this is swap function\n");
	//printf ("after swapping x=%d and y=%d\n", x,y);
}
