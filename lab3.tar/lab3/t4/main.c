#include<stdio.h>
#include"myMath.h"
int main()
{
	int x,y;
	printf("Enter num1 : ");
	scanf("%d",&x);
	printf("Enter num2 : ");
	scanf("%d",&y);
	int equal =isEqual(x,y);
	if(equal==1)
		printf ("%d and %d are equal\n", x,y);
	else
		printf (" %d and %d are not equal\n", x,y);
	printf ("before swaping x=%d and y=%d \n", x,y);
	swap(&x,&y);
	printf ("after swaping x=%d and y=%d \n", x,y);
}	
