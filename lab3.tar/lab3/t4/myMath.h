int isEqual(int, int);
void swap(int *, int *);