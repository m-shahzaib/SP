#include <stdio.h>
#include<stdlib.h>
int main()
{
	int *arr=(int*) malloc (sizeof(int) * 10);
		for(int i=0;i<10;i++)
		{
			printf("Enter number to be entered in array:\n");
			scanf("%d",&arr[i]);
		}
		printf("array data:\n");
		for(int i=0;i<10;i++)
		{
			printf("%d \n",arr[i]);
		}
		arr=(int*)realloc(arr,20);
		printf("increasing array size:\n");
		
		for(int i=0;i<20;i++)
		{
			printf("\nEnter number to be entered in array:");
			scanf("%d",&arr[i]);
		}
		printf("array data:\n");

		for(int i=0;i<20;i++)
		{
			printf("%d \n",arr[i]);
		}
}