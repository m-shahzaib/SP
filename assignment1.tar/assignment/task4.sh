#!/bin/bash

read -p "Enter a file name : " fileName
cat $fileName
echo "\nfile after removing duplicate lines..................................."


#sort $fileName | uniq -c 1> file1
#sort $fileName | uniq -cd | sort -nr

sort $fileName | uniq -u > aNewfile

rm $fileName

cat aNewfile>$fileName
rm aNewfile

#a=( $fileName )
#sort -u $fileName
#`awk '!a[$@]++' $fileName`
cat $fileName