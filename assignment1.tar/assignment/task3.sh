#!/bin/bash

lower_case_conversion()
{
	read -p "Enter a string to be converted into loweer_case : " string
#	echo ${string,,}
	string=${string,,}
	echo $string
}

user_root()
{
	root_id=`cut -d ":" -f 3 /etc/passwd`
	user_id=`id -u`
	if [ $root_id -eq $user_id ]
	then
		echo "User is root"
	else
		echo "User is not root"
	fi
}

user_exists()
{
	read -p "Enter a user name you want to search : " user
	getent passwd $user > /dev/null
	if [ $? -eq 0 ]
	then 
		echo "user exisits"
	else
		echo "user does not exists"
	fi
}
lower_case_conversion 
user_root
user_exists
