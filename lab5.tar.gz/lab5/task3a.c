#include<stdio.h>
#include<unistd.h>

int main()
{
	int cpid = fork();
	if(cpid == 0)
	{
		// Child
		printf("The Child's PID is : %d\n", getpid());
		printf("The Child's PPID is : %d\n", (long)getppid());
	
	} 
	else
	{
		// Parent
		printf("The Parent's PID is : %d\n", getpid());
		printf("The Parent's PPID is : %d\n", (long)getppid());
	}
	return 0;
}
