#include<stdio.h>
#include<unistd.h>

int main()
{
	int ruid, euid, suid;
	int rgid, egid, sgid;
	int status_id = getresuid(&ruid, &euid, &suid);
	int status_gid = getresgid(&rgid, &egid, &sgid);
	printf("The Real ID is : %d\nThe Effective ID is : %d\nThe Saved UID is : %d\n\n", ruid, euid, suid);
	printf("The Real Group ID is : %d\nThe Effective Group ID is : %d\nThe Saved Group UID is : %d\n", ruid, euid, suid);
	
	return 0;
}
