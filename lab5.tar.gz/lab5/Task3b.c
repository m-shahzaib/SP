#include<stdio.h>
#include<unistd.h>

int main()
{
	int status=0;
	int cpid = fork();
	if(cpid == 0)
	{
		// Child
		printf("The Child's PID is : %d\n", getpid());
	
	} 
	else
	{
		// Parent
		printf("The Parent's PID is : %d\n", getpid());
		if(WIFEXITED(status))
		printf("Normal termination, exit status = %d\n",
		WEXITSTATUS(status));
		else if (WIFSIGNALED(status))
		printf("Terminated by signal number = %d\n",WTERMSIG(status));
	}
	
	return 0;
}
