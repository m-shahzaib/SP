#include<stdio.h>
#include<unistd.h>

int main()
{
	int cpid = fork();
	if(cpid == 0)
	{
		// Child
		printf("The Child's PID is : %d\n", getpid());
		execl("/bin/bash","mybash","-c",cmd,'\0');
	} 
	else
	{
		// Parent
		wait();
		printf("Terminated by signal number = %d\n",WTERMSIG(status));
	}
	return 0;
	}
}
