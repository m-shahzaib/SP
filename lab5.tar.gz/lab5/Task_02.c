#include<stdio.h>
#include<unistd.h>

int main()
{
	int ruid, euid, suid;
	int rgid, egid, sgid;
	int status_id = getresuid(&ruid, &euid, &suid);
	int status_gid = getresgid(&rgid, &egid, &sgid);
	printf("The Real ID is : %d\nThe Effective ID is : %d\nThe Saved UID is : %d\n\n", ruid, euid, suid);
	printf("The Real Group ID is : %d\nThe Effective Group ID is : %d\nThe Saved Group UID is : %d\n", ruid, euid, suid);
	
	int rv = setuid(501);
	if (rv != -1){
	getresuid(&ruid, &euid, &suid);
	printf("\n\nAfter setuid(501) the IDs are:\n");
	printf("My Real user-ID is: %d\n", (long)ruid);
	printf("My Effective user-ID is: %d\n", (long)euid);
	printf("My Saved Set-user-ID is: %d\n", (long)suid);
	}
	else
	printf ("Error in setting ID\n");
	
	return 0;
}
