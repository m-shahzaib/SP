#!/bin/bash

a=$1
b=$2
if [ $# -eq 0 ]
then
	read -p "enter first number : " a
	read -p "enter second number : " b
fi

if [ $# -eq 1 ]
then
	read -p "enter second number : " b
fi

echo "Addition" `expr $a + $b`
echo "Subtraction" `expr $a - $b`
if [ $b -ne 0 ]
then
	echo "Division" `expr $a / $b`
else
	echo "division is not possible because second number is 0"
fi

echo "Multiplication" `expr $a \* $b`

