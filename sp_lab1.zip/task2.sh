#!/bin/bash

details=(`ls -l file1`)

echo "Owner: " ${details[2]}
echo "Group: " ${details[3]}
echo "Permissions: " ${details[0]}
echo "Filename: " ${details[8]}
if(test ${details[3]}=${details[2]})
then
	echo "Cheating: " 0
else
	echo "Cheating: " 1
fi

diff -c file1 file2


