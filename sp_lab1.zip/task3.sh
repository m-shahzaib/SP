#!/bin/bash
UNIX=( Debin 'Red hat' Ubuntu Suse Fedora )

echo "All values of array: " ${UNIX[*]}
echo "Length of array: "  ${#UNIX[*]}
echo "length of element on index 2: " ${#UNIX[2]}
echo "Extracted 2 elements from position 3: " ${UNIX[3]} ${UNIX[4]}

echo ${UNIX[*]:3:2}

# search and replace element
echo "Searching and replacing ubuntu for array: "${UNIX[*]/Ubuntu/SCO}

# add element in existing array

#UNIX=(${UNIX[*] "AIX" "HP-UX")

echo "removed the 3 element : " unset UNIX[2]

# new array linux and copy elements of UNIX
LINUX=(${UNIX[*]})

echo "all elements of array LINUX: " ${LINUX[*]}

#creating new array and concatenate UNIX and LINUX
BASH=(${UNIX[*]} ${LINUX[*]})

echo "NEW array after concatenating: " ${BASH[*]}

unset UNIX[*]
unset LINUX[*]


