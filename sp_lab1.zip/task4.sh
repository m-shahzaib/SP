#!/bin/bash
array=( `cat file` )
echo "All elements of array: " ${array[*]}
echo "Length of array : " ${#array[*]}
echo "Length of index 3 element: " ${array[2]}
